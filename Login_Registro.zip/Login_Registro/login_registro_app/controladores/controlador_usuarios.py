from flask import Flask, session, render_template, redirect, request
from login_registro_app import app
from login_registro_app.modelos.modelo_usuarios import Usuario #importante importar clases para enroutar
from flask_bcrypt import Bcrypt
from flask import flash

bcrypt=Bcrypt(app)

@app.route('/') #Primer metodo de despliegue de plantilla HTML
def desplegar_login_registro():
    return render_template('login_registro.html')

@app.route('/crear/usuario', methods=['POST']) #ruta correspondiente a registro, llamo al diccionario
def nuevo_usuario():
    data = {
        **request.form
    }
    if Usuario.validar_registro (data)==False:
        return redirect('/')
    else:
        password_encriptado = bcrypt.generate_password_hash(data['password'])
        data ['password'] = password_encriptado
        id_usuario = Usuario.crear_uno(data)
        session['nombre']=data['nombre']
        session['apellido']=data['apellido']
        session['id_usuario'] = id_usuario

        return redirect('/dashboard') #CREAR RUTA !

@app.route('/dashboard')
def desplegar_dashboard():
    #condiciones para vaciar las credenciales
    if 'nombre' not in session:
        return redirect('/')
    else:
        return render_template ('dashboard.html')

@app.route('/procesa/login',methods=['POST']) #validacion y solicitud query 
def procesa_login():
    data={
        "email": request.form['email_login']
    }
    usuario = Usuario.obtener_uno_con_email(data)

    if usuario == None:
        flash('Email invalido','error_email_login')
        return redirect('/')
    else:
        if not bcrypt.check_password_hash (usuario.password, request.form['password_login']): #si no coinciden tras proceso de validacion, envio flash
            flash ("Credenciales incorrectas", "error_password_login")
        else:
            session['nombre'] = usuario.nombre
            session['apellido'] =usuario.apellido
            session['id_usuario'] = usuario.id
            return redirect ('/dashboard')

@app.route ('/logout', methods = ['POST'])
def procesa_logout():
    session.clear()
    return redirect ('/') 

#@app.route ('/logout', methods = ['POST'])
#def procesa_logout():
    #session.clear()
    #return redirect ('/')  ->>> asi a secas puedo seguir accediendo, hay que vaciar credenciales

