from login_registro_app import app
from login_registro_app.controladores import controlador_usuarios #CREO CONTROLADOR Y LO IMPORTO AUTOMATICAMENTE EN SERVER

if __name__ == "__main__":
    app.run(debug = True, port = 5001 )

